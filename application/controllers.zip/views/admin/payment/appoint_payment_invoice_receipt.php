<?php echo$amp->name; ?>

helllo