<?php foreach($times as $time): ?>
  <option value="<?php echo$time->time ?>"><?php  echo$time->time; ?></option>
<?php endforeach; ?>