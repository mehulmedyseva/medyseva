<div class="content-wrapper hide-save">
	<div class="container hide-save">
		<?php include"include/prescription_details.php"; ?>
	</div>
</div>